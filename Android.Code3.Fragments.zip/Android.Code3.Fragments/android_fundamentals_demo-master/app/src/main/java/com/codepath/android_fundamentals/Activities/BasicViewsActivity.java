package com.codepath.android_fundamentals.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.codepath.android_fundamentals.R;

public class BasicViewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_views);
    }
}
