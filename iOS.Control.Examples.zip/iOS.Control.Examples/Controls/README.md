Controls
==============

This sample illustrates the different Controls available in Xamarin.iOS, which can be used to build your User Interface. This sample is related to the '[User Interface Objects](http://docs.xamarin.com/guides/ios/user_interface/controls/)' series of documents.


