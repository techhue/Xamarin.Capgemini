SimpleLogin
==========

This sample is the application that will be built at the end of the [Creating iOS Applications in Code Using Visual Studio](http://developer.xamarin.com/guides/ios/application_fundamentals/ios_code_only/) guide.




