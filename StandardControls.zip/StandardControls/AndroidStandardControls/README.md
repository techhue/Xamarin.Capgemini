Standard Controls
=====================

This sample demonstrates Android's built-in UI controls.

Form Controls: TextView, EditText, AutoCompleteTextView, Button, CheckBox, RadioGroup, RatingBar

Content Controls: ImageView, Gallery, ScrollView, GridView

Progress Controls: Progress Dialog, Progress Bar

Popups: Toast, Alert

Pickers: Spinner, DatePickerDialog, TimePickerDialog

Menus: Options Menu, Context Menu

Layouts: Tab Layout, RelativeLayout, LinearLayout, FrameLayout, TableLayout


Authors
-------

Craig Dunn