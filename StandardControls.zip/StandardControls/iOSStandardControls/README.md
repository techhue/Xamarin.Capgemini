Standard Controls
=================
This example application illustrates how to use a number of standard controls including: 
* Action Sheet
* Activity Spinner
* Alert View
* Button
* Date Picker
* Image View
* Label
* Pager Control
* Progress Bar
* Scroll View
* Segmented Control
* Slider
* Switch
* Text Field
* Toolbar

Authors
-------
Bryan Costanich
