// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;

namespace Example_StandardControls.Screens.iPhone.SegmentedControl
{
    [Register ("SegmentedControls2_iPhone")]
    partial class SegmentedControls2_iPhone
    {
        void ReleaseDesignerOutlets ()
        {
        }
    }
}